import { User } from "./User";

const MOCK_USERS = [
    new User('f26e461-50bb-4107-9eb5-', 'asdasd', 'asdasd', '123456Mm!', 'male', 'user', '/default-male.jpg', 'asd', 'active', '2022-05-17T09:20:20.000Z', '2022-05-17T09:20:20.000Z')
];

export default MOCK_USERS;