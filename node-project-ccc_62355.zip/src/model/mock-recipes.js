import { Recipe } from "./Recipe"

const MOCK_RECIPES = [
    new Recipe('fd55285-0b0a-4f0b-984c-','f26e461-50bb-4107-9eb5-', 'test', 'test na summary', 55, 'hlqb, olio', 'https://recepti.gotvach.bg/files/lib/250x250/pecheno_pile_nadaska.jpg',
               'testov long description', 'pile, pecheno', '2022-05-17T09:57:41.963Z', '2022-05-17T09:57:41.963Z')
];

export default MOCK_RECIPES;