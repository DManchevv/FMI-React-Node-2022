import React from 'react'
import './css/bootstrap5.css'

export const NotFound = () => {
  return (
    <div>
        <h2 className='text-light'>Error 404</h2>
        <h2 className='text-light'>Page is not found!</h2>
    </div>
  )
}
