import React, { useEffect, useState } from "react";
import '../css/bootstrap5.css'
import 'https://use.fontawesome.com/releases/v5.15.4/js/all.js'
import '../css/productManagement.css'
import BackOfficeProduct from "./BackOfficeProduct";
import BackOfficeOrder from "./BackOfficeOrder";

export default function OrderManagement() {
    const [orders, setOrders] = useState([]);

    let scrollCounter = 0;
    let lastSelectedColumn = 0;
    let isSortAscending = false;

    useEffect(() => {
        getOrders();
    }, []);

    function getOrders() {
        fetch('/order-management/get-all/1', {
            method: 'GET'
        })
        .then(response => response.json())
        .then(data => {
            console.log(data);
            setOrders(data);
        })
    }

    function filterTable(isClearingTable, sortCol = 0, clickInvoked = false, ascending = true, event) {
        if (clickInvoked === true) {
            console.log(lastSelectedColumn);
            console.log(isSortAscending);
            if (lastSelectedColumn == sortCol) {
                isSortAscending = !isSortAscending;
                ascending = isSortAscending;
            }
            else {
                lastSelectedColumn = sortCol;
                isSortAscending = true;
            }
        
            let allTableHeaders = document.getElementsByClassName('table-header');
        
            for (let i = 0; i < allTableHeaders.length; i++) {
                if (allTableHeaders[i].classList.contains('headerUnsorted') === false) {
                    allTableHeaders[i].classList.remove('headerSortDown');
                    allTableHeaders[i].classList.remove('headerSortUp');
                    allTableHeaders[i].classList.add('headerUnsorted');
                }
            }
    
            if (ascending === false) {
                event.target.classList.add('headerSortDown');
                event.target.classList.remove('headerSortUp');
                event.target.classList.remove('headerUnsorted');
            }
            else {
                event.target.classList.add('headerSortUp');
                event.target.classList.remove('headerSortDown');
                event.target.classList.remove('headerUnsorted');
            }
        }
        else {
            if (isSortAscending === false) {
                ascending = false;
            }
        }
    
        const numberOfSelects = 7;
        const numberOfTextFields = 4;
        let allTableRows = document.querySelectorAll('.products-table .temporary-data');
        let responseMessage = document.getElementById('response-msg');
    
        let selects = [];
        let textFields = [];
    
        for (let i = 1; i <= numberOfSelects; i++) {
            selects.push(document.getElementById('select-' + i));
        }
    
        for (let i = 1; i <= numberOfTextFields; i++) {
            textFields.push(document.getElementById('text-filter-' + i));
        }
    
        let tmp = scrollCounter;
    
        if (isClearingTable) {
            scrollCounter = 0;
        }
    
        /*fetch("/order-management/filter-table-data/" + scrollCounter, {
            idSymbol: selects[0].value,
            idValue: textFields[0].value,
            dateSymbol: selects[1].value,
            dateValue: textFields[1].value,
            status: selects[2].value,
            type: selects[3].value,
            buyerIDSymbol: selects[4].value,
            buyerIDValue: textFields[2].value,
            priceSymbol: selects[5].value,
            priceValue: textFields[3].value,
            currency: selects[6].value,
            sortCol: sortCol,
            ascending: ascending
        }, function(data) {
            responseMessage.innerText = "";
    
            if (isClearingTable) {
    
                for (let i = 0; i < allTableRows.length; i++) {
                    allTableRows[i].remove();
                }
            }
        
            isRequestSent = false;
        })
          .fail(function(res) {
              scrollCounter = tmp;
    
              let message = JSON.parse(res.responseText);
    
              if (res.status === 460 || res.status === 530) {
                responseMessage.innerText = message.error;
              }
    
          });
    */
        
    }
    return(
        <div className="mx-auto main-content">
                <div className="container-fluid text-center response" id="response-msg"></div>
                <h1 className="text-center">Поръчки</h1>
                <table id="products-table" className="products-table">
                    <tbody>
                        <tr className="filter-row">
                            <td>
                                <div className="d-flex flex-column align-items-center">
                                    <select id="select-1">
                                        <option value="=">=</option>
                                        <option value="<">&lt;</option>
                                        <option value=">">&gt;</option>
                                    </select>
                                </div>
                                <input type="text" id="text-filter-1" onChange={() => filterTable(true)} />
                            </td>
                            <td>
                                <div className="d-flex flex-column align-items-center">
                                    <select id="select-2">
                                        <option value="=">=</option>
                                        <option value="<">&lt;</option>
                                        <option value=">">&gt;</option>
                                    </select>
                                    <input type="text" id="text-filter-2" onChange={() => filterTable(true)} />
                                </div>
                            </td>
                            <td>
                                <select id="select-3" onChange={() => filterTable(true)}>
                                    <option value="all">Всички</option>
                                </select>
                            </td>
                            <td>
                                <select id="select-4" onChange={() => filterTable(true)}>
                                    <option value="all">Всички</option>
                                </select>
                            </td>
                            <td>
                                <div className="d-flex flex-column align-items-center">
                                    <select id="select-5">
                                        <option value="=">=</option>
                                        <option value="<">&lt;</option>
                                        <option value=">">&gt;</option>
                                    </select>
                                    <input type="text" id="text-filter-3" onChange={() => filterTable(true)} />
                                </div>
                            </td>
                            <td>
                                <div className="d-flex flex-column align-items-center">
                                    <select id="select-6">
                                        <option value="=">=</option>
                                        <option value="<">&lt;</option>
                                        <option value=">">&gt;</option>
                                    </select>
                                    <input type="text" id="text-filter-4" onChange={() => filterTable(true)} />
                                </div>
                            </td>
                            <td>
                                <select id="select-7" onChange={() => filterTable(true)}>
                                    <option value="all">Всички</option>
                                </select>
                            </td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td className="interactable table-header headerUnsorted" onClick={event => filterTable(true, 0, true, true, event)}>Пореден Номер</td>
                            <td className="interactable table-header headerUnsorted" onClick={event => filterTable(true, 1, true, true, event)}>Дата</td>
                            <td className="interactable table-header headerUnsorted" onClick={event => filterTable(true, 2, true, true, event)}>Статус</td>
                            <td className="interactable table-header headerUnsorted" onClick={event => filterTable(true, 3, true, true, event)}>Тип</td>
                            <td className="interactable table-header headerUnsorted" onClick={event => filterTable(true, 4, true, true, event)}>ID на купувача</td>
                            <td className="interactable table-header headerUnsorted" onClick={event => filterTable(true, 5, true, true, event)}>Обща сума</td>
                            <td className="interactable table-header headerUnsorted" onClick={event => filterTable(true, 6, true, true, event)}>Валута</td>
                            <td>Продукти</td>
                            <td>Смени статус</td>
                        </tr>
                        {orders.map(order => (
                            <BackOfficeOrder key={order.id} order={order}/>
                        ))}
                    </tbody>
                </table>
            </div>
    );
}