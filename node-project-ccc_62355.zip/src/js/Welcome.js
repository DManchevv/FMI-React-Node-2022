import React from 'react';
import '../css/styles.css'
import '../css/bootstrap5.css'
export const Welcome = () => {
    return (
        <div className={"container-fluid section1 d-flex justify-content-around"}>
		    <img src="/megaSale.png" alt="home"/>
	    </div>
    )
}